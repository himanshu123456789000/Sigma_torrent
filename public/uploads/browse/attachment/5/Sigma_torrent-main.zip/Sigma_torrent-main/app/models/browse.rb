class Browse < ApplicationRecord
    has_many_attached :files
end
