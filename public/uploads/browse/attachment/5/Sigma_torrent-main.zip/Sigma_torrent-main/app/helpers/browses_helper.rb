module BrowsesHelper
end
