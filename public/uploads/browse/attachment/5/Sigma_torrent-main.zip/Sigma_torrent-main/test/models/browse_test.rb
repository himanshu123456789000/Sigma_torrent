require "test_helper"

class BrowseTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
